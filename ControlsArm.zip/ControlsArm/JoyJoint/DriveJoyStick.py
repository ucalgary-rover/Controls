#Created by the one and only Ramisa Islam

import pygame
from Phidget22.Phidget import *
from Phidget22.PhidgetException import *
from Phidget22.Devices.Stepper import *
from Phidget22.Devices.RCServo import *
from Phidget22.Devices.DCMotor import * 
import traceback
import time

VHubSerial_motors = 697103
VHubSerial_servo = 697066

leftSideDriveMotors = DCMotor()
rightSideDriveMotors = DCMotor()

def  driver_init():
    leftSideDriveMotors.setHubPort(0)
    rightSideDriveMotors.setHubPort(5)

    leftSideDriveMotors.setDeviceSerialNumber(VHubSerial_motors)
    leftSideDriveMotors.setCurrentLimit(10)
    leftSideDriveMotors.setTargetVelocity(0)
    leftSideDriveMotors.setAcceleration(5)
    leftSideDriveMotors.setFanMode(DCMotorFanMode.DCMOTOR_FAN_MODE_OFF)

    rightSideDriveMotors.setDeviceSerialNumber(VHubSerial_motors)
    leftSideDriveMotors.setCurrentLimit(10)
    rightSideDriveMotors.setTargetVelocity(0)
    rightSideDriveMotors.setAcceleration(5)
    rightSideDriveMotors.setFanMode(DCMotorFanMode.DCMOTOR_FAN_MODE_OFF)

    try:
        leftSideDriveMotors.openWaitForAttachment(5000)
        rightSideDriveMotors.openWaitForAttachment(5000)
        print("Test connection")
        print("Drivers connected")
    except:
        print("Failed to connect")
        print("Drivers not connected")
    leftSideDriveMotors.setControlMode(DCMotorControlMode.DCMOTOR_CONTROL_MODE_SPEED)
    rightSideDriveMotors.setControlMode(DCMotorControlMode.DCMOTOR_CONTROL_MODE_SPEED)
    leftSideDriveMotors.setAcceleration(1000)
    rightSideDriveMotors.setAcceleration(1000)
    leftSideDriveMotors.setVelocityLimit(100)
    rightSideDriveMotors.setVelocityLimit(100)
    leftSideDriveMotors.setTargetVelocity(0)
    rightSideDriveMotors.setTargetVelocity(0)

def drive_forward():
    leftSideDriveMotors.setTargetVelocity(.35)
    rightSideDriveMotors.setTargetVelocity(-.35)

def drive_backward():
    leftSideDriveMotors.setTargetVelocity(-.35)
    rightSideDriveMotors.setTargetVelocity(.35)

def drive_left():
    leftSideDriveMotors.setTargetVelocity(-1)
    rightSideDriveMotors.setTargetVelocity(-1)

def drive_right():
    leftSideDriveMotors.setTargetVelocity(1)
    rightSideDriveMotors.setTargetVelocity(1)

def drive_stop():
    leftSideDriveMotors.setTargetVelocity(0)
    rightSideDriveMotors.setTargetVelocity(0)